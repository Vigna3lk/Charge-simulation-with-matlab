# 模块4: 超启发式框架 (hyperheuristic.py)
import random
import numpy as np
from typing import List, Callable, Dict
from problem import Problem
from solution import Solution, Route
import copy

class HyperHeuristic:
    def __init__(self, problem: Problem, low_level_heuristics: list = None):
        self.problem = problem
        
        # 创新点1: 自适应学习率的低级启发式选择机制
        self.heuristics = low_level_heuristics if low_level_heuristics else self._default_heuristics()
        self.performance = [1.0] * len(self.heuristics)  # 各启发式表现记录
        self.usage_count = [0] * len(self.heuristics)    # 使用次数记录
        self.success_count = [0] * len(self.heuristics)  # 成功改进次数
        self.learning_rates = [0.1] * len(self.heuristics)  # 自适应学习率
        
        # 创新点2: 分阶段搜索策略
        self.search_phases = ['diversification', 'intensification', 'path_optimization']
        self.current_phase = 'diversification'
        self.phase_counter = 0
        self.max_phase_iter = 30  # 每阶段最大迭代次数
        
        # 创新点3: 自适应记忆分群策略
        self.solution_pool = []  # 解池
        self.max_pool_size = 10  # 最大解池大小
        self.similarity_threshold = 0.7  # 相似度阈值
        
        # 搜索历史
        self.search_history = []
        self.tabu_moves = []
        self.tabu_tenure = 5
        
    def _default_heuristics(self) -> List[Callable]:
        """默认低级启发式算子集合"""
        return [
            # 中转站开放状态相关操作
            self._open_transfer_station,       # 开放一个中转站
            self._close_transfer_station,      # 关闭一个中转站
            
            # 分配相关操作
            self._reassign_generation,         # 重新分配产生点
            self._reassign_waste_to_demand,    # 重新分配废物到需求点
            
            # 路径优化操作
            self._swap_nodes_in_route,         # 交换同一路线中的两个节点
            self._two_opt_move,                # 2-opt移动
            
            # 综合性操作
            self._rebalance_routes,            # 平衡路径负载
            self._add_charging_station,        # 添加充电站到路径
            
            # 创新操作
            self._merge_routes,                # 合并两条路径
            self._split_route,                 # 分割一条路径
            self._inter_route_swap             # 路径间节点交换
        ]
        
    def select_heuristic(self):
        """选择低级启发式算子"""
        # 根据搜索阶段选择不同类型的启发式
        if self.current_phase == 'diversification':
            # 多样化阶段，更倾向于使用多样性操作
            diversity_boost = [1.5, 1.5, 1.2, 1.2, 0.8, 0.8, 1.0, 1.0, 1.5, 1.5, 1.2]
            weights = [p * b for p, b in zip(self.performance, diversity_boost)]
        elif self.current_phase == 'intensification':
            # 集中化阶段，更倾向于使用改进操作
            intensity_boost = [0.8, 0.8, 1.0, 1.0, 1.2, 1.2, 1.5, 1.2, 0.8, 0.8, 1.0]
            weights = [p * b for p, b in zip(self.performance, intensity_boost)]
        else:  # path_optimization
            # 路径优化阶段，专注于路径操作
            path_boost = [0.5, 0.5, 0.8, 0.8, 1.5, 1.8, 1.5, 1.2, 1.0, 1.2, 1.5]
            weights = [p * b for p, b in zip(self.performance, path_boost)]
            
        # 轮盘赌选择
        total = sum(weights)
        if total == 0:  # 防止除零错误
            return random.randint(0, len(self.heuristics)-1)
            
        r = random.uniform(0, total)
        cumulative = 0
        for i, w in enumerate(weights):
            cumulative += w
            if r <= cumulative:
                return i
        return len(self.heuristics)-1
        
    def update_performance(self, idx: int, improvement: float, success: bool):
        """更新启发式表现"""
        # 更新统计信息
        self.usage_count[idx] += 1
        if success:
            self.success_count[idx] += 1
            
        # 计算成功率
        success_rate = self.success_count[idx] / max(1, self.usage_count[idx])
        
        # 自适应学习率
        self.learning_rates[idx] = min(0.5, max(0.05, success_rate))
        
        # 更新性能
        lr = self.learning_rates[idx]
        self.performance[idx] = (1 - lr) * self.performance[idx] + lr * improvement
        
    def update_search_phase(self, iter_count: int, no_improvement: int):
        """更新搜索阶段"""
        self.phase_counter += 1
        
        # 根据无改进迭代次数和总迭代次数切换阶段
        if self.phase_counter >= self.max_phase_iter or no_improvement >= self.max_phase_iter // 2:
            self.phase_counter = 0
            
            # 切换到下一阶段
            current_idx = self.search_phases.index(self.current_phase)
            next_idx = (current_idx + 1) % len(self.search_phases)
            self.current_phase = self.search_phases[next_idx]
            
            # 随着迭代进行，调整各阶段的最大迭代次数
            if iter_count > 300:
                phase_weights = {'diversification': 0.2, 'intensification': 0.5, 'path_optimization': 0.3}
            else:
                phase_weights = {'diversification': 0.4, 'intensification': 0.3, 'path_optimization': 0.3}
                
            self.max_phase_iter = int(30 * phase_weights[self.current_phase])
            
    def solution_similarity(self, sol1: Solution, sol2: Solution) -> float:
        """计算两个解的相似度"""
        similarity = 0.0
        
        # 中转站开放状态相似度
        same_transfer = sum(1 for t in sol1.transfer_stations if sol1.transfer_stations[t] == sol2.transfer_stations[t])
        transfer_sim = same_transfer / max(1, len(sol1.transfer_stations))
        
        # 产生点分配相似度
        same_assignments = sum(1 for g in sol1.generation_to_transfer 
                            if g in sol2.generation_to_transfer and 
                            sol1.generation_to_transfer[g] == sol2.generation_to_transfer[g])
        assignment_sim = same_assignments / max(1, len(sol1.generation_to_transfer))
        
        # 计算总相似度
        similarity = 0.4 * transfer_sim + 0.6 * assignment_sim
        
        return similarity
        
    def update_solution_pool(self, solution: Solution):
        """更新解池"""
        # 计算新解与池中解的相似度
        similarities = [self.solution_similarity(solution, sol) for sol in self.solution_pool]
        
        # 如果池未满或新解与池中解相似度都小于阈值，直接添加
        if len(self.solution_pool) < self.max_pool_size or (similarities and max(similarities) < self.similarity_threshold):
            self.solution_pool.append(solution.copy())
            if len(self.solution_pool) > self.max_pool_size:
                # 移除最差的解
                costs = [sol.calculate_cost() for sol in self.solution_pool]
                worst_idx = costs.index(max(costs))
                self.solution_pool.pop(worst_idx)
        else:
            # 找出最相似的解
            most_similar_idx = similarities.index(max(similarities))
            similar_sol = self.solution_pool[most_similar_idx]
            
            # 如果新解更好，则替换
            if solution.calculate_cost() < similar_sol.calculate_cost():
                self.solution_pool[most_similar_idx] = solution.copy()
                
    def run(self, max_iter=1000, max_no_improve=100):
        """运行超启发式算法"""
        # 初始解
        current = self.generate_initial_solution()
        best = current.copy()
        best_cost = current.calculate_cost()
        
        # 初始化解池
        self.solution_pool = [current.copy()]
        
        # 搜索计数器
        iter_count = 0
        no_improvement_count = 0
        
        while iter_count < max_iter and no_improvement_count < max_no_improve:
            # 更新搜索阶段
            self.update_search_phase(iter_count, no_improvement_count)
            
            # 5%概率从解池中选择一个解作为当前解(创新点3)
            if random.random() < 0.05 and len(self.solution_pool) > 1:
                pool_sols = [sol for sol in self.solution_pool if sol != current]
                if pool_sols:
                    current = random.choice(pool_sols).copy()
            
            # 选择并应用低级启发式
            h_idx = self.select_heuristic()
            
            # 如果该操作在禁忌表中，则选择下一个
            attempt_count = 0
            while (h_idx, iter_count) in self.tabu_moves and attempt_count < 3:
                h_idx = self.select_heuristic()
                attempt_count += 1
                
            # 应用启发式
            new_sol = self.heuristics[h_idx](current.copy())
            new_cost = new_sol.calculate_cost()
            current_cost = current.calculate_cost()
            
            # 检查改进
            is_improved = False
            if new_sol.is_feasible() and new_cost < current_cost:
                improvement = (current_cost - new_cost) / current_cost
                is_improved = True
                
                # 更新当前解
                current = new_sol
                no_improvement_count = 0
                
                # 更新最佳解
                if new_cost < best_cost:
                    best = new_sol.copy()
                    best_cost = new_cost
                    print(f"迭代 {iter_count}: 发现新的最佳成本 {best_cost}")
                
                # 更新解池
                self.update_solution_pool(new_sol)
            else:
                improvement = 0
                no_improvement_count += 1
                
                # 一定概率接受较差解(模拟退火)
                if random.random() < 0.1 * (max_iter - iter_count) / max_iter:
                    current = new_sol
            
            # 更新启发式性能
            self.update_performance(h_idx, improvement, is_improved)
            
            # 更新禁忌表
            self.tabu_moves.append((h_idx, iter_count))
            while len(self.tabu_moves) > 0 and iter_count - self.tabu_moves[0][1] > self.tabu_tenure:
                self.tabu_moves.pop(0)
            
            # 记录搜索历史
            self.search_history.append((iter_count, h_idx, is_improved, new_cost))
            
            iter_count += 1
            
        # 返回最佳解
        return best
        
    def generate_initial_solution(self) -> Solution:
        """生成初始解"""
        sol = Solution(self.problem)
        
        # 1. 开放一些中转站
        transfer_nodes = [n.id for n in self.problem.nodes if n.type == 'transfer']
        num_to_open = max(1, len(transfer_nodes) // 2)
        open_transfers = random.sample(transfer_nodes, num_to_open)
        for tid in transfer_nodes:
            sol.transfer_stations[tid] = tid in open_transfers
        
        # 2. 分配产生点到最近的开放中转站
        for node in self.problem.nodes:
            if node.type == 'generation':
                # 找到最近的开放中转站
                min_dist = float('inf')
                nearest_transfer = None
                for tid in open_transfers:
                    dist = self.problem.distance_matrix[node.id, tid]
                    if dist < min_dist:
                        min_dist = dist
                        nearest_transfer = tid
                if nearest_transfer:
                    sol.generation_to_transfer[node.id] = nearest_transfer
                
        # 3. 分配废物到相应的需求点
        demand_nodes = {n.id: n.demand_type for n in self.problem.nodes if n.type == 'demand'}
        for tid in open_transfers:
            sol.transfer_to_demand[tid] = {}
            for waste_type in self.problem.processed_waste_types:
                # 找到处理此废物的需求点
                for did, dtype in demand_nodes.items():
                    if dtype == waste_type:
                        sol.transfer_to_demand[tid][waste_type] = did
                        break
        
        # 4. 构建两层级路径
        from ga import GeneticAlgorithm
        ga = GeneticAlgorithm(self.problem)
        ga._build_first_level_routes(sol)
        ga._build_second_level_routes(sol)
        
        return sol

    # 低级启发式操作定义
    
    def _open_transfer_station(self, solution: Solution) -> Solution:
        """开放一个中转站"""
        closed_transfers = [tid for tid, is_open in solution.transfer_stations.items() if not is_open]
        if closed_transfers:
            tid = random.choice(closed_transfers)
            solution.transfer_stations[tid] = True
            
            # 更新路径
            from ga import GeneticAlgorithm
            ga = GeneticAlgorithm(self.problem)
            ga._build_first_level_routes(solution)
            ga._build_second_level_routes(solution)
            
        return solution
    
    def _close_transfer_station(self, solution: Solution) -> Solution:
        """关闭一个中转站"""
        open_transfers = [tid for tid, is_open in solution.transfer_stations.items() if is_open]
        if len(open_transfers) > 1:  # 确保至少保留一个开放的中转站
            tid = random.choice(open_transfers)
            solution.transfer_stations[tid] = False
            
            # 重新分配产生点
            affected_gens = [gid for gid, t in solution.generation_to_transfer.items() if t == tid]
            remaining_transfers = [t for t in open_transfers if t != tid]
            for gid in affected_gens:
                if remaining_transfers:
                    solution.generation_to_transfer[gid] = random.choice(remaining_transfers)
            
            # 更新路径
            from ga import GeneticAlgorithm
            ga = GeneticAlgorithm(self.problem)
            ga._build_first_level_routes(solution)
            ga._build_second_level_routes(solution)
            
        return solution
    
    def _reassign_generation(self, solution: Solution) -> Solution:
        """重新分配产生点"""
        if solution.generation_to_transfer:
            # 随机选择一个产生点
            gid = random.choice(list(solution.generation_to_transfer.keys()))
            
            # 找出所有开放的中转站
            open_transfers = [tid for tid, is_open in solution.transfer_stations.items() if is_open]
            if open_transfers:
                # 分配到新的中转站
                solution.generation_to_transfer[gid] = random.choice(open_transfers)
                
                # 更新路径
                from ga import GeneticAlgorithm
                ga = GeneticAlgorithm(self.problem)
                ga._build_first_level_routes(solution)
                
        return solution
    
    def _reassign_waste_to_demand(self, solution: Solution) -> Solution:
        """重新分配废物到需求点"""
        if solution.transfer_to_demand:
            # 随机选择一个中转站
            tid = random.choice(list(solution.transfer_to_demand.keys()))
            
            if tid in solution.transfer_to_demand:
                # 随机选择一种废物类型
                waste_types = list(solution.transfer_to_demand[tid].keys())
                if waste_types:
                    waste_type = random.choice(waste_types)
                    
                    # 找出处理此类废物的需求点
                    demand_nodes = [n for n in self.problem.nodes if n.type == 'demand' and n.demand_type == waste_type]
                    if demand_nodes:
                        # 分配到新的需求点
                        solution.transfer_to_demand[tid][waste_type] = random.choice(demand_nodes).id
                        
                        # 更新路径
                        from ga import GeneticAlgorithm
                        ga = GeneticAlgorithm(self.problem)
                        ga._build_second_level_routes(solution)
                
        return solution
    
    def _swap_nodes_in_route(self, solution: Solution) -> Solution:
        """交换同一路线中的两个节点"""
        # 随机选择一层级
        level = random.choice(['first', 'second'])
        
        if level == 'first' and solution.first_level_routes:
            # 随机选择一个中转站的路径
            tid = random.choice(list(solution.first_level_routes.keys()))
            if solution.first_level_routes[tid]:
                # 随机选择一条路径
                route_idx = random.randrange(len(solution.first_level_routes[tid]))
                route = solution.first_level_routes[tid][route_idx]
                
                # 确保路径有足够的节点可以交换
                if len(route.path) > 3:
                    # 选择两个不是depot的节点进行交换
                    idx1 = random.randint(1, len(route.path) - 2)
                    idx2 = random.randint(1, len(route.path) - 2)
                    route.path[idx1], route.path[idx2] = route.path[idx2], route.path[idx1]
        
        elif level == 'second' and solution.second_level_routes:
            # 随机选择一个需求点的路径
            did = random.choice(list(solution.second_level_routes.keys()))
            if solution.second_level_routes[did]:
                # 随机选择一条路径
                route_idx = random.randrange(len(solution.second_level_routes[did]))
                route = solution.second_level_routes[did][route_idx]
                
                # 确保路径有足够的节点可以交换
                if len(route.path) > 3:
                    # 选择两个不是depot的节点进行交换
                    idx1 = random.randint(1, len(route.path) - 2)
                    idx2 = random.randint(1, len(route.path) - 2)
                    route.path[idx1], route.path[idx2] = route.path[idx2], route.path[idx1]
        
        return solution
    
    def _two_opt_move(self, solution: Solution) -> Solution:
        """2-opt移动"""
        # 随机选择一层级
        level = random.choice(['first', 'second'])
        
        if level == 'first' and solution.first_level_routes:
            # 随机选择一个中转站的路径
            tid = random.choice(list(solution.first_level_routes.keys()))
            if solution.first_level_routes[tid]:
                # 随机选择一条路径
                route_idx = random.randrange(len(solution.first_level_routes[tid]))
                route = solution.first_level_routes[tid][route_idx]
                
                # 确保路径有足够的节点
                if len(route.path) > 4:
                    # 选择两个点进行2-opt
                    i = random.randint(1, len(route.path) - 3)
                    j = random.randint(i + 1, len(route.path) - 2)
                    
                    # 反转i到j之间的节点
                    route.path[i:j+1] = reversed(route.path[i:j+1])
        
        elif level == 'second' and solution.second_level_routes:
            # 随机选择一个需求点的路径
            did = random.choice(list(solution.second_level_routes.keys()))
            if solution.second_level_routes[did]:
                # 随机选择一条路径
                route_idx = random.randrange(len(solution.second_level_routes[did]))
                route = solution.second_level_routes[did][route_idx]
                
                # 确保路径有足够的节点
                if len(route.path) > 4:
                    # 选择两个点进行2-opt
                    i = random.randint(1, len(route.path) - 3)
                    j = random.randint(i + 1, len(route.path) - 2)
                    
                    # 反转i到j之间的节点
                    route.path[i:j+1] = list(reversed(route.path[i:j+1]))
        
        return solution
    
    def _rebalance_routes(self, solution: Solution) -> Solution:
        """平衡路径负载"""
        # 随机选择一层级
        level = random.choice(['first', 'second'])
        
        if level == 'first' and solution.first_level_routes:
            # 随机选择一个中转站
            tid = random.choice(list(solution.first_level_routes.keys()))
            if len(solution.first_level_routes[tid]) > 1:  # 确保有多条路径可以平衡
                # 找出负载最重和最轻的路径
                route_loads = []
                for idx, route in enumerate(solution.first_level_routes[tid]):
                    total_load = sum(sum(loads.values()) for loads in route.loads.values())
                    route_loads.append((idx, total_load))
                
                # 按负载排序
                route_loads.sort(key=lambda x: x[1], reverse=True)
                
                # 从负载最重的路径中选一个节点，移到负载最轻的路径
                heavy_idx, _ = route_loads[0]
                light_idx, _ = route_loads[-1]
                
                heavy_route = solution.first_level_routes[tid][heavy_idx]
                light_route = solution.first_level_routes[tid][light_idx]
                
                # 确保重路径有中间节点可以移动
                if len(heavy_route.path) > 3:
                    # 选择一个非depot节点
                    node_idx = random.randint(1, len(heavy_route.path) - 2)
                    node = heavy_route.path[node_idx]
                    
                    # 从重路径中移除
                    heavy_route.path.pop(node_idx)
                    
                    # 在轻路径的合适位置插入
                    if len(light_route.path) > 2:
                        # 找到插入位置（使距离增加最小）
                        best_pos = 1  # 默认插入到第一个非depot位置
                        min_extra_dist = float('inf')
                        
                        for i in range(1, len(light_route.path)):
                            prev = light_route.path[i-1]
                            curr = light_route.path[i]
                            
                            # 计算插入节点后增加的距离
                            old_dist = self.problem.distance_matrix[prev, curr]
                            new_dist = self.problem.distance_matrix[prev, node] + self.problem.distance_matrix[node, curr]
                            extra = new_dist - old_dist
                            
                            if extra < min_extra_dist:
                                min_extra_dist = extra
                                best_pos = i
                        
                        # 插入节点
                        light_route.path.insert(best_pos, node)
                        
                        # 转移装载信息
                        if node in heavy_route.loads:
                            light_route.loads[node] = heavy_route.loads[node]
                            del heavy_route.loads[node]
        
        elif level == 'second' and solution.second_level_routes:
            # 类似逻辑应用于第二层级路径
            did = random.choice(list(solution.second_level_routes.keys()))
            if len(solution.second_level_routes[did]) > 1:
                # 找出负载最重和最轻的路径
                route_loads = []
                for idx, route in enumerate(solution.second_level_routes[did]):
                    total_load = sum(sum(loads.values()) for loads in route.loads.values())
                    route_loads.append((idx, total_load))
                
                route_loads.sort(key=lambda x: x[1], reverse=True)
                heavy_idx, _ = route_loads[0]
                light_idx, _ = route_loads[-1]
                
                heavy_route = solution.second_level_routes[did][heavy_idx]
                light_route = solution.second_level_routes[did][light_idx]
                
                if len(heavy_route.path) > 3:
                    node_idx = random.randint(1, len(heavy_route.path) - 2)
                    node = heavy_route.path[node_idx]
                    
                    heavy_route.path.pop(node_idx)
                    
                    if len(light_route.path) > 2:
                        best_pos = 1
                        min_extra_dist = float('inf')
                        
                        for i in range(1, len(light_route.path)):
                            prev = light_route.path[i-1]
                            curr = light_route.path[i]
                            old_dist = self.problem.distance_matrix[prev, curr]
                            new_dist = self.problem.distance_matrix[prev, node] + self.problem.distance_matrix[node, curr]
                            extra = new_dist - old_dist
                            
                            if extra < min_extra_dist:
                                min_extra_dist = extra
                                best_pos = i
                        
                        light_route.path.insert(best_pos, node)
                        
                        if node in heavy_route.loads:
                            light_route.loads[node] = heavy_route.loads[node]
                            del heavy_route.loads[node]
        
        return solution

    def _add_charging_station(self, solution: Solution) -> Solution:
        """添加充电站到电动车路径中"""
        if solution.first_level_routes:
            # 随机选择一个中转站的路径
            tid = random.choice(list(solution.first_level_routes.keys()))
            if solution.first_level_routes[tid]:
                # 随机选择一条路径
                route_idx = random.randrange(len(solution.first_level_routes[tid]))
                route = solution.first_level_routes[tid][route_idx]
                
                # 选择两个相邻节点
                if len(route.path) > 2:
                    # 找到可能需要充电的段落
                    potential_segments = []
                    for i in range(len(route.path) - 1):
                        from_node = route.path[i]
                        to_node = route.path[i+1]
                        energy_needed = self.problem.distance_matrix[from_node, to_node] * self.problem.energy_consumption
                        # 如果能量需求大于阈值，认为可能需要充电
                        if energy_needed > self.problem.battery_capacity * 0.3:  # 30%阈值
                            potential_segments.append(i)
                    
                    # 如果有潜在需要充电的段落
                    if potential_segments:
                        segment_idx = random.choice(potential_segments)
                        from_node = route.path[segment_idx]
                        to_node = route.path[segment_idx+1]
                        
                        # 找到最近的充电站
                        charging_stations = [n.id for n in self.problem.nodes if n.type == 'charging']
                        if charging_stations:
                            best_charging = min(charging_stations, 
                                            key=lambda c: (self.problem.distance_matrix[from_node, c] + 
                                                            self.problem.distance_matrix[c, to_node]))
                            
                            # 插入充电站
                            route.path.insert(segment_idx+1, best_charging)
                            
                            # 更新能量使用情况
                            if hasattr(route, 'energy_usage') and hasattr(route, 'remaining_energy'):
                                if route.energy_usage:
                                    # 分割原能量使用为两段
                                    original_energy = route.energy_usage[segment_idx]
                                    energy_to_charging = self.problem.distance_matrix[from_node, best_charging] * self.problem.energy_consumption
                                    energy_from_charging = self.problem.distance_matrix[best_charging, to_node] * self.problem.energy_consumption
                                    
                                    # 更新能量使用列表
                                    route.energy_usage[segment_idx] = energy_to_charging
                                    route.energy_usage.insert(segment_idx+1, energy_from_charging)
                                    
                                    # 更新剩余能量列表
                                    if route.remaining_energy:
                                        remaining_before = route.remaining_energy[segment_idx] - original_energy + energy_to_charging
                                        route.remaining_energy.insert(segment_idx+1, self.problem.battery_capacity)  # 充满电
        
        return solution

    def _merge_routes(self, solution: Solution) -> Solution:
        """合并两条路径"""
        # 随机选择一层级
        level = random.choice(['first', 'second'])
        
        if level == 'first' and solution.first_level_routes:
            # 随机选择一个中转站
            tid = random.choice(list(solution.first_level_routes.keys()))
            if len(solution.first_level_routes[tid]) > 1:  # 确保有多条路径可以合并
                # 随机选择两条路径
                idx1, idx2 = random.sample(range(len(solution.first_level_routes[tid])), 2)
                route1 = solution.first_level_routes[tid][idx1]
                route2 = solution.first_level_routes[tid][idx2]
                
                # 检查合并后容量是否超限
                total_load1 = sum(sum(loads.values()) for loads in route1.loads.values())
                total_load2 = sum(sum(loads.values()) for loads in route2.loads.values())
                
                if total_load1 + total_load2 <= self.problem.vehicle_capacity:
                    # 可以合并路径
                    # 保留depot到depot之间的路径段
                    merged_path = [route1.path[0]]  # 起始于转运站
                    merged_path.extend(route1.path[1:-1])  # 添加中间节点
                    merged_path.extend(route2.path[1:])    # 添加第二条路径的节点(包括返回转运站)
                    
                    # 合并装载量
                    merged_loads = route1.loads.copy()
                    for node, loads in route2.loads.items():
                        if node in merged_loads:
                            for waste_type, amount in loads.items():
                                if waste_type in merged_loads[node]:
                                    merged_loads[node][waste_type] += amount
                                else:
                                    merged_loads[node][waste_type] = amount
                        else:
                            merged_loads[node] = loads.copy()
                    
                    # 创建新路径
                    new_route = Route(merged_path)
                    new_route.loads = merged_loads
                    
                    # 如果是电动车路径，需要计算能量
                    if hasattr(route1, 'energy_usage'):
                        new_route.energy_usage = []
                        new_route.remaining_energy = []
                        
                        # 简单处理:重新计算能量
                        current_energy = self.problem.battery_capacity
                        for i in range(len(merged_path) - 1):
                            from_node = merged_path[i]
                            to_node = merged_path[i+1]
                            energy_used = self.problem.distance_matrix[from_node, to_node] * self.problem.energy_consumption
                            new_route.energy_usage.append(energy_used)
                            current_energy -= energy_used
                            new_route.remaining_energy.append(current_energy)
                    
                    # 移除原来的路径，添加新路径
                    routes = solution.first_level_routes[tid]
                    if idx1 > idx2:
                        routes.pop(idx1)
                        routes.pop(idx2)
                    else:
                        routes.pop(idx2)
                        routes.pop(idx1)
                    routes.append(new_route)
        
        elif level == 'second' and solution.second_level_routes:
            # 类似逻辑用于第二层级路径
            did = random.choice(list(solution.second_level_routes.keys()))
            if len(solution.second_level_routes[did]) > 1:
                idx1, idx2 = random.sample(range(len(solution.second_level_routes[did])), 2)
                route1 = solution.second_level_routes[did][idx1]
                route2 = solution.second_level_routes[did][idx2]
                
                total_load1 = sum(sum(loads.values()) for loads in route1.loads.values())
                total_load2 = sum(sum(loads.values()) for loads in route2.loads.values())
                
                if total_load1 + total_load2 <= self.problem.vehicle_capacity:
                    merged_path = [route1.path[0]]
                    merged_path.extend(route1.path[1:-1])
                    merged_path.extend(route2.path[1:])
                    
                    merged_loads = route1.loads.copy()
                    for node, loads in route2.loads.items():
                        if node in merged_loads:
                            for waste_type, amount in loads.items():
                                if waste_type in merged_loads[node]:
                                    merged_loads[node][waste_type] += amount
                                else:
                                    merged_loads[node][waste_type] = amount
                        else:
                            merged_loads[node] = loads.copy()
                    
                    new_route = Route(merged_path)
                    new_route.loads = merged_loads
                    
                    routes = solution.second_level_routes[did]
                    if idx1 > idx2:
                        routes.pop(idx1)
                        routes.pop(idx2)
                    else:
                        routes.pop(idx2)
                        routes.pop(idx1)
                    routes.append(new_route)
        
        return solution

    def _split_route(self, solution: Solution) -> Solution:
        """分割一条路径为两条"""
        # 随机选择一层级
        level = random.choice(['first', 'second'])
        
        if level == 'first' and solution.first_level_routes:
            # 随机选择一个中转站
            tid = random.choice(list(solution.first_level_routes.keys()))
            if solution.first_level_routes[tid]:
                # 随机选择一条路径来分割
                route_idx = random.randrange(len(solution.first_level_routes[tid]))
                route = solution.first_level_routes[tid][route_idx]
                
                # 确保路径足够长可以分割
                if len(route.path) > 4:  # 至少需要depot + 2个访问节点 + depot
                    # 选择分割点
                    split_idx = random.randint(2, len(route.path) - 2)
                    
                    # 创建两条新路径
                    path1 = route.path[:split_idx]
                    path1.append(route.path[0])  # 返回depot
                    
                    path2 = [route.path[0]]  # 从depot开始
                    path2.extend(route.path[split_idx:])
                    
                    # 分割装载量
                    loads1 = {}
                    loads2 = {}
                    
                    for node in path1[1:-1]:  # 排除depot
                        if node in route.loads:
                            loads1[node] = route.loads[node]
                    
                    for node in path2[1:-1]:  # 排除depot
                        if node in route.loads:
                            loads2[node] = route.loads[node]
                    
                    # 创建新路径对象
                    new_route1 = Route(path1)
                    new_route1.loads = loads1
                    
                    new_route2 = Route(path2)
                    new_route2.loads = loads2
                    
                    # 处理能量问题
                    if hasattr(route, 'energy_usage'):
                        # 第一条路径的能量使用
                        new_route1.energy_usage = route.energy_usage[:split_idx-1]
                        new_route1.energy_usage.append(self.problem.distance_matrix[path1[-2], path1[-1]] * self.problem.energy_consumption)
                        
                        # 第二条路径的能量使用
                        new_route2.energy_usage = [self.problem.distance_matrix[path2[0], path2[1]] * self.problem.energy_consumption]
                        new_route2.energy_usage.extend(route.energy_usage[split_idx-1:])
                        
                        # 计算剩余能量
                        new_route1.remaining_energy = []
                        current_energy = self.problem.battery_capacity
                        for energy in new_route1.energy_usage:
                            current_energy -= energy
                            new_route1.remaining_energy.append(current_energy)
                        
                        new_route2.remaining_energy = []
                        current_energy = self.problem.battery_capacity
                        for energy in new_route2.energy_usage:
                            current_energy -= energy
                            new_route2.remaining_energy.append(current_energy)
                    
                    # 替换原路径
                    solution.first_level_routes[tid][route_idx] = new_route1
                    solution.first_level_routes[tid].append(new_route2)
        
        elif level == 'second' and solution.second_level_routes:
            # 类似的逻辑用于第二层级路径
            did = random.choice(list(solution.second_level_routes.keys()))
            if solution.second_level_routes[did]:
                route_idx = random.randrange(len(solution.second_level_routes[did]))
                route = solution.second_level_routes[did][route_idx]
                
                if len(route.path) > 4:
                    split_idx = random.randint(2, len(route.path) - 2)
                    
                    path1 = route.path[:split_idx]
                    path1.append(route.path[0])
                    
                    path2 = [route.path[0]]
                    path2.extend(route.path[split_idx:])
                    
                    loads1 = {}
                    loads2 = {}
                    
                    for node in path1[1:-1]:
                        if node in route.loads:
                            loads1[node] = route.loads[node]
                    
                    for node in path2[1:-1]:
                        if node in route.loads:
                            loads2[node] = route.loads[node]
                    
                    new_route1 = Route(path1)
                    new_route1.loads = loads1
                    
                    new_route2 = Route(path2)
                    new_route2.loads = loads2
                    
                    solution.second_level_routes[did][route_idx] = new_route1
                    solution.second_level_routes[did].append(new_route2)
        
        return solution

    def _inter_route_swap(self, solution: Solution) -> Solution:
        """在两条不同路径之间交换节点"""
        # 随机选择一层级
        level = random.choice(['first', 'second'])
        
        if level == 'first' and solution.first_level_routes:
            # 随机选择一个中转站
            tid = random.choice(list(solution.first_level_routes.keys()))
            if len(solution.first_level_routes[tid]) > 1:  # 确保有多条路径
                # 随机选择两条路径
                idx1, idx2 = random.sample(range(len(solution.first_level_routes[tid])), 2)
                route1 = solution.first_level_routes[tid][idx1]
                route2 = solution.first_level_routes[tid][idx2]
                
                # 确保两条路径都有中间节点可交换
                if len(route1.path) > 3 and len(route2.path) > 3:
                    # 选择非depot节点进行交换
                    node1_idx = random.randint(1, len(route1.path) - 2)
                    node2_idx = random.randint(1, len(route2.path) - 2)
                    
                    node1 = route1.path[node1_idx]
                    node2 = route2.path[node2_idx]
                    
                    # 交换节点
                    route1.path[node1_idx] = node2
                    route2.path[node2_idx] = node1
                    
                    # 交换装载量信息
                    if node1 in route1.loads and node2 in route2.loads:
                        route1.loads[node2] = route2.loads[node2]
                        route2.loads[node1] = route1.loads[node1]
                        del route1.loads[node1]
                        del route2.loads[node2]
                    
                    # 重新计算能量使用情况
                    if hasattr(route1, 'energy_usage'):
                        for route in [route1, route2]:
                            route.energy_usage = []
                            route.remaining_energy = []
                            current_energy = self.problem.battery_capacity
                            
                            for i in range(len(route.path) - 1):
                                from_node = route.path[i]
                                to_node = route.path[i+1]
                                energy_used = self.problem.distance_matrix[from_node, to_node] * self.problem.energy_consumption
                                route.energy_usage.append(energy_used)
                                current_energy -= energy_used
                                route.remaining_energy.append(current_energy)
        
        elif level == 'second' and solution.second_level_routes:
            # 类似的逻辑用于第二层级路径
            did = random.choice(list(solution.second_level_routes.keys()))
            if len(solution.second_level_routes[did]) > 1:
                idx1, idx2 = random.sample(range(len(solution.second_level_routes[did])), 2)
                route1 = solution.second_level_routes[did][idx1]
                route2 = solution.second_level_routes[did][idx2]
                
                if len(route1.path) > 3 and len(route2.path) > 3:
                    node1_idx = random.randint(1, len(route1.path) - 2)
                    node2_idx = random.randint(1, len(route2.path) - 2)
                    
                    node1 = route1.path[node1_idx]
                    node2 = route2.path[node2_idx]
                    
                    route1.path[node1_idx] = node2
                    route2.path[node2_idx] = node1
                    
                    if node1 in route1.loads and node2 in route2.loads:
                        route1.loads[node2] = route2.loads[node2]
                        route2.loads[node1] = route1.loads[node1]
                        del route1.loads[node1]
                        del route2.loads[node2]
        
        return solution