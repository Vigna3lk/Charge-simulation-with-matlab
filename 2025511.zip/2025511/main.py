# 模块5: 主程序与比较 (main.py)
from problem import Problem
from ga import GeneticAlgorithm
from hyperheuristic import HyperHeuristic
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D
import matplotlib.colors as mcolors
import random
import matplotlib.font_manager as fm
import os
import platform

def setup_chinese_fonts():
    """设置支持中文显示的字体"""
    system = platform.system()
    
    if system == 'Windows':
        # Windows系统优先使用微软雅黑
        if os.path.exists('C:/Windows/Fonts/msyh.ttc'):
            plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
        elif os.path.exists('C:/Windows/Fonts/simhei.ttf'):
            plt.rcParams['font.sans-serif'] = ['SimHei']
        else:
            available_fonts = [f.name for f in fm.fontManager.ttflist]
            for font in ['Microsoft YaHei', 'SimHei', 'SimSun', 'NSimSun']:
                if font in available_fonts:
                    plt.rcParams['font.sans-serif'] = [font]
                    break
    elif system == 'Linux':
        # Linux系统优先使用文泉驿等开源字体
        plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'WenQuanYi Zen Hei', 'AR PL UMing CN']
    elif system == 'Darwin':  # macOS
        plt.rcParams['font.sans-serif'] = ['Hiragino Sans GB', 'STHeiti', 'Apple LiGothic Medium']
    
    # 使用负号而不是unicode
    plt.rcParams['axes.unicode_minus'] = False

def main():
    # 设置中文字体支持
    setup_chinese_fonts()
    
    # 初始化问题实例
    problem = Problem()
    # 生成测试数据
    problem.generate_test_data(num_generation=20, num_transfer=6, num_charging=3, num_demand=3)
    
    print("问题规模:")
    print(f"产生点数量: {len([n for n in problem.nodes if n.type == 'generation'])}")
    print(f"中转站数量: {len([n for n in problem.nodes if n.type == 'transfer'])}")
    print(f"充电站数量: {len([n for n in problem.nodes if n.type == 'charging'])}")
    print(f"需求点数量: {len([n for n in problem.nodes if n.type == 'demand'])}")
    
    # 运行遗传算法
    print("\n开始运行遗传算法...")
    ga = GeneticAlgorithm(problem, pop_size=30, max_gen=50)
    ga_solution = ga.run()
    
    # 运行超启发式算法
    print("\n开始运行超启发式算法...")
    hh = HyperHeuristic(problem)  # 使用默认的低级启发式集合
    hh_solution = hh.run(max_iter=300, max_no_improve=50)
    
    # 结果比较
    print("\n算法结果比较:")
    print(f"GA 解决方案成本: {ga_solution.calculate_cost():.2f}")
    print(f"HH 解决方案成本: {hh_solution.calculate_cost():.2f}")
    
    # 解决方案详情
    print("\n遗传算法解决方案:")
    print_solution_details(ga_solution)
    
    print("\n超启发式算法解决方案:")
    print_solution_details(hh_solution)
    
    # 进行统计显著性对比分析
    if ga_solution.calculate_cost() > hh_solution.calculate_cost():
        improvement = (ga_solution.calculate_cost() - hh_solution.calculate_cost()) / ga_solution.calculate_cost() * 100
        print(f"\n超启发式算法相比遗传算法改进了 {improvement:.2f}%")
    else:
        improvement = (hh_solution.calculate_cost() - ga_solution.calculate_cost()) / hh_solution.calculate_cost() * 100
        print(f"\n遗传算法相比超启发式算法改进了 {improvement:.2f}%")
    
    # 可视化结果
    visualize_network(problem, hh_solution)
    compare_costs(problem, ga_solution, hh_solution)
    visualize_routes(problem, hh_solution)
    plot_waste_distribution(problem, hh_solution)

def print_solution_details(solution):
    """打印解决方案详情"""
    print(f"  开放中转站数量: {sum(1 for is_open in solution.transfer_stations.values() if is_open)}")
    
    # 第一层级路径数量
    first_level_routes = sum(len(routes) for routes in solution.first_level_routes.values())
    print(f"  第一层级路径数量: {first_level_routes}")
    
    # 第二层级路径数量
    second_level_routes = sum(len(routes) for routes in solution.second_level_routes.values())
    print(f"  第二层级路径数量: {second_level_routes}")
    
    # 未收集废物量
    uncollected = sum(sum(waste_dict.values()) for waste_dict in solution.uncollected_waste.values())
    print(f"  未收集废物总量: {uncollected:.2f}")
    
    # 解的可行性
    print(f"  解的可行性: {'可行' if solution.is_feasible() else '不可行'}")
    
    # 成本分析
    total_cost = solution.calculate_cost()
    print(f"  总成本: {total_cost:.2f}")

def visualize_network(problem, solution):
    """可视化网络拓扑和路径"""
    plt.figure(figsize=(15, 10))
    
    # 设置节点颜色和标志
    node_colors = {
        'generation': 'green',
        'transfer': 'red',
        'charging': 'blue',
        'demand': 'purple'
    }
    
    node_markers = {
        'generation': 'o',  # 圆形
        'transfer': 's',    # 方形
        'charging': '^',    # 三角形
        'demand': 'D'       # 钻石形
    }
    
    # 绘制所有节点
    for node in problem.nodes:
        plt.scatter(node.x, node.y, c=node_colors[node.type], 
                   marker=node_markers[node.type], s=100, 
                   edgecolors='black', zorder=5)
        plt.text(node.x + 1, node.y + 1, f"{node.id}", fontsize=8)
    
    # 标记开放的中转站
    for tid, is_open in solution.transfer_stations.items():
        if is_open:
            node = next((n for n in problem.nodes if n.id == tid), None)
            if node:
                plt.scatter(node.x, node.y, c='yellow', marker='*', s=300, 
                           edgecolors='black', zorder=10)
    
    # 绘制第一层级路径 - 实线
    colors = list(mcolors.CSS4_COLORS.values())
    random.shuffle(colors)
    color_idx = 0
    
    for tid, routes in solution.first_level_routes.items():
        for route in routes:
            if len(route.path) > 1:
                for i in range(len(route.path) - 1):
                    from_node = next((n for n in problem.nodes if n.id == route.path[i]), None)
                    to_node = next((n for n in problem.nodes if n.id == route.path[i+1]), None)
                    if from_node and to_node:
                        plt.plot([from_node.x, to_node.x], [from_node.y, to_node.y], 
                               c=colors[color_idx % len(colors)], linestyle='-', linewidth=1.2, zorder=1)
                        # 添加方向箭头
                        plt.arrow(from_node.x, from_node.y, 
                                 (to_node.x - from_node.x) * 0.9, 
                                 (to_node.y - from_node.y) * 0.9,
                                 head_width=1, head_length=1, fc=colors[color_idx % len(colors)], 
                                 ec=colors[color_idx % len(colors)], zorder=2)
            color_idx += 1
    
    # 绘制第二层级路径 - 虚线
    for did, routes in solution.second_level_routes.items():
        for route in routes:
            if len(route.path) > 1:
                for i in range(len(route.path) - 1):
                    from_node = next((n for n in problem.nodes if n.id == route.path[i]), None)
                    to_node = next((n for n in problem.nodes if n.id == route.path[i+1]), None)
                    if from_node and to_node:
                        plt.plot([from_node.x, to_node.x], [from_node.y, to_node.y], 
                               c=colors[color_idx % len(colors)], linestyle='--', linewidth=1.0, zorder=1)
            color_idx += 1
    
    # 添加图例
    legend_elements = [
        Line2D([0], [0], marker='o', color='w', markerfacecolor='green', markersize=10, label='产生点'),
        Line2D([0], [0], marker='s', color='w', markerfacecolor='red', markersize=10, label='中转站'),
        Line2D([0], [0], marker='^', color='w', markerfacecolor='blue', markersize=10, label='充电站'),
        Line2D([0], [0], marker='D', color='w', markerfacecolor='purple', markersize=10, label='需求点'),
        Line2D([0], [0], marker='*', color='w', markerfacecolor='yellow', markersize=15, label='开放中转站'),
        Line2D([0], [0], linestyle='-', color='black', label='第一层级路径'),
        Line2D([0], [0], linestyle='--', color='black', label='第二层级路径')
    ]
    
    plt.legend(handles=legend_elements, loc='upper right')
    plt.title('建筑固废收集与转运网络拓扑及最优路径规划', fontsize=15)
    plt.xlabel('X坐标')
    plt.ylabel('Y坐标')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.savefig('network_visualization.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("网络拓扑图已保存为 'network_visualization.png'")

def compare_costs(problem, ga_solution, hh_solution):
    """比较两种算法的各项成本"""
    # 计算GA成本细节
    ga_transfer_cost = 0
    ga_vehicle_fixed_cost = 0
    ga_transport_cost = 0
    ga_charging_cost = 0
    ga_penalty_cost = 0
    
    # 计算中转站成本
    for tid, is_open in ga_solution.transfer_stations.items():
        if is_open:
            node = next((n for n in problem.nodes if n.id == tid), None)
            if node:
                ga_transfer_cost += node.setup_cost
    
    # 计算车辆固定成本
    ga_vehicle_fixed_cost = (len([r for routes in ga_solution.first_level_routes.values() for r in routes]) * problem.ev_fixed_cost +
                            len([r for routes in ga_solution.second_level_routes.values() for r in routes]) * problem.truck_fixed_cost)
    
    # 计算运输和充电成本
    for tid, routes in ga_solution.first_level_routes.items():
        for route in routes:
            for i in range(len(route.path) - 1):
                from_id = route.path[i]
                to_id = route.path[i+1]
                distance = problem.distance_matrix[from_id, to_id]
                ga_transport_cost += distance * problem.ev_transport_cost
                
                # 如果到达充电站，计算充电成本
                to_node = next((n for n in problem.nodes if n.id == to_id), None)
                if to_node and to_node.type == 'charging':
                    ga_charging_cost += problem.battery_capacity * problem.charging_cost
    
    for did, routes in ga_solution.second_level_routes.items():
        for route in routes:
            for i in range(len(route.path) - 1):
                from_id = route.path[i]
                to_id = route.path[i+1]
                distance = problem.distance_matrix[from_id, to_id]
                ga_transport_cost += distance * problem.truck_transport_cost
    
    # 计算惩罚成本
    ga_penalty_cost = sum(sum(waste_dict.values()) for waste_dict in ga_solution.uncollected_waste.values()) * problem.penalty_cost
    
    # 以同样方式计算HH成本
    hh_transfer_cost = 0
    hh_vehicle_fixed_cost = 0
    hh_transport_cost = 0
    hh_charging_cost = 0
    hh_penalty_cost = 0
    
    for tid, is_open in hh_solution.transfer_stations.items():
        if is_open:
            node = next((n for n in problem.nodes if n.id == tid), None)
            if node:
                hh_transfer_cost += node.setup_cost
    
    hh_vehicle_fixed_cost = (len([r for routes in hh_solution.first_level_routes.values() for r in routes]) * problem.ev_fixed_cost +
                            len([r for routes in hh_solution.second_level_routes.values() for r in routes]) * problem.truck_fixed_cost)
    
    for tid, routes in hh_solution.first_level_routes.items():
        for route in routes:
            for i in range(len(route.path) - 1):
                from_id = route.path[i]
                to_id = route.path[i+1]
                distance = problem.distance_matrix[from_id, to_id]
                hh_transport_cost += distance * problem.ev_transport_cost
                
                to_node = next((n for n in problem.nodes if n.id == to_id), None)
                if to_node and to_node.type == 'charging':
                    hh_charging_cost += problem.battery_capacity * problem.charging_cost
    
    for did, routes in hh_solution.second_level_routes.items():
        for route in routes:
            for i in range(len(route.path) - 1):
                from_id = route.path[i]
                to_id = route.path[i+1]
                distance = problem.distance_matrix[from_id, to_id]
                hh_transport_cost += distance * problem.truck_transport_cost
    
    hh_penalty_cost = sum(sum(waste_dict.values()) for waste_dict in hh_solution.uncollected_waste.values()) * problem.penalty_cost
    
    # 创建柱状图数据
    cost_categories = ['中转站成本', '车辆固定成本', '运输成本', '充电成本', '惩罚成本', '总成本']
    ga_costs = [ga_transfer_cost, ga_vehicle_fixed_cost, ga_transport_cost, 
               ga_charging_cost, ga_penalty_cost, ga_solution.calculate_cost()]
    hh_costs = [hh_transfer_cost, hh_vehicle_fixed_cost, hh_transport_cost, 
               hh_charging_cost, hh_penalty_cost, hh_solution.calculate_cost()]
    
    # 绘制柱状图
    x = np.arange(len(cost_categories))
    width = 0.35
    
    fig, ax = plt.subplots(figsize=(14, 8))
    rects1 = ax.bar(x - width/2, ga_costs, width, label='遗传算法', color='skyblue')
    rects2 = ax.bar(x + width/2, hh_costs, width, label='超启发式算法', color='lightgreen')
    
    # 添加标签和标题
    ax.set_ylabel('成本', fontsize=12)
    ax.set_title('遗传算法与超启发式算法成本对比', fontsize=16)
    ax.set_xticks(x)
    ax.set_xticklabels(cost_categories, fontsize=10)
    ax.legend(fontsize=12)
    
    # 添加数值标签
    def autolabel(rects):
        for rect in rects:
            height = rect.get_height()
            ax.annotate(f'{height:.2f}',
                       xy=(rect.get_x() + rect.get_width() / 2, height),
                       xytext=(0, 3),
                       textcoords="offset points",
                       ha='center', va='bottom',
                       fontsize=8)
    
    autolabel(rects1)
    autolabel(rects2)
    
    fig.tight_layout()
    plt.savefig('cost_comparison.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("成本对比图已保存为 'cost_comparison.png'")

def visualize_routes(problem, solution):
    """分别可视化第一层级和第二层级路径"""
    # 第一层级路径可视化
    plt.figure(figsize=(15, 10))
    
    node_colors = {
        'generation': 'green',
        'transfer': 'red',
        'charging': 'blue',
    }
    
    node_markers = {
        'generation': 'o',  # 圆形
        'transfer': 's',    # 方形
        'charging': '^',    # 三角形
    }
    
    # 只绘制与第一层级相关的节点
    for node in problem.nodes:
        if node.type in ['generation', 'transfer', 'charging']:
            plt.scatter(node.x, node.y, c=node_colors[node.type], 
                       marker=node_markers[node.type], s=100, 
                       edgecolors='black', zorder=5)
            plt.text(node.x + 1, node.y + 1, f"{node.id}", fontsize=8)
    
    # 标记开放的中转站
    for tid, is_open in solution.transfer_stations.items():
        if is_open:
            node = next((n for n in problem.nodes if n.id == tid), None)
            if node:
                plt.scatter(node.x, node.y, c='yellow', marker='*', s=300, 
                           edgecolors='black', zorder=10)
    
    # 绘制第一层级路径，不同中转站的路径用不同颜色
    colors = list(mcolors.CSS4_COLORS.values())
    random.shuffle(colors)
    color_idx = 0
    
    # 为每个中转站创建一个图例条目
    legend_elements = []
    
    for tid, routes in solution.first_level_routes.items():
        if routes:  # 如果该中转站有路径
            route_color = colors[color_idx % len(colors)]
            color_idx += 1
            
            # 找到中转站名称
            transfer_node = next((n for n in problem.nodes if n.id == tid), None)
            transfer_name = f"中转站 {tid}"
            
            # 添加到图例
            legend_elements.append(Line2D([0], [0], color=route_color, lw=2, label=transfer_name))
            
            # 绘制该中转站的所有路径
            for route in routes:
                if len(route.path) > 1:
                    for i in range(len(route.path) - 1):
                        from_node = next((n for n in problem.nodes if n.id == route.path[i]), None)
                        to_node = next((n for n in problem.nodes if n.id == route.path[i+1]), None)
                        if from_node and to_node:
                            plt.plot([from_node.x, to_node.x], [from_node.y, to_node.y], 
                                   c=route_color, linestyle='-', linewidth=1.5, zorder=1)
                            # 添加方向箭头
                            plt.arrow(from_node.x, from_node.y, 
                                     (to_node.x - from_node.x) * 0.9, 
                                     (to_node.y - from_node.y) * 0.9,
                                     head_width=1, head_length=1, fc=route_color, 
                                     ec=route_color, zorder=2)
    
    # 添加节点类型图例
    node_legend = [
        Line2D([0], [0], marker='o', color='w', markerfacecolor='green', markersize=10, label='产生点'),
        Line2D([0], [0], marker='s', color='w', markerfacecolor='red', markersize=10, label='中转站'),
        Line2D([0], [0], marker='^', color='w', markerfacecolor='blue', markersize=10, label='充电站'),
        Line2D([0], [0], marker='*', color='w', markerfacecolor='yellow', markersize=15, label='开放中转站')
    ]
    
    legend_elements = node_legend + legend_elements
    plt.legend(handles=legend_elements, loc='upper right')
    plt.title('第一层级电动车路径规划', fontsize=15)
    plt.xlabel('X坐标')
    plt.ylabel('Y坐标')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.savefig('first_level_routes.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 第二层级路径可视化
    plt.figure(figsize=(15, 10))
    
    node_colors = {
        'transfer': 'red',
        'demand': 'purple'
    }
    
    node_markers = {
        'transfer': 's',  # 方形
        'demand': 'D'     # 钻石形
    }
    
    # 只绘制与第二层级相关的节点
    for node in problem.nodes:
        if node.type in ['transfer', 'demand']:
            plt.scatter(node.x, node.y, c=node_colors[node.type], 
                       marker=node_markers[node.type], s=100, 
                       edgecolors='black', zorder=5)
            plt.text(node.x + 1, node.y + 1, f"{node.id}", fontsize=8)
    
    # 标记开放的中转站
    for tid, is_open in solution.transfer_stations.items():
        if is_open:
            node = next((n for n in problem.nodes if n.id == tid), None)
            if node:
                plt.scatter(node.x, node.y, c='yellow', marker='*', s=300, 
                           edgecolors='black', zorder=10)
    
    # 绘制第二层级路径，不同需求点的路径用不同颜色
    colors = list(mcolors.CSS4_COLORS.values())
    random.shuffle(colors)
    color_idx = 0
    
    # 为每个需求点创建一个图例条目
    legend_elements = []
    
    for did, routes in solution.second_level_routes.items():
        if routes:  # 如果该需求点有路径
            route_color = colors[color_idx % len(colors)]
            color_idx += 1
            
            # 找到需求点信息
            demand_node = next((n for n in problem.nodes if n.id == did), None)
            demand_name = f"需求点 {did}"
            if demand_node and hasattr(demand_node, 'demand_type'):
                demand_name += f" ({demand_node.demand_type})"
            
            # 添加到图例
            legend_elements.append(Line2D([0], [0], color=route_color, lw=2, label=demand_name))
            
            # 绘制该需求点的所有路径
            for route in routes:
                if len(route.path) > 1:
                    for i in range(len(route.path) - 1):
                        from_node = next((n for n in problem.nodes if n.id == route.path[i]), None)
                        to_node = next((n for n in problem.nodes if n.id == route.path[i+1]), None)
                        if from_node and to_node:
                            plt.plot([from_node.x, to_node.x], [from_node.y, to_node.y], 
                                   c=route_color, linestyle='--', linewidth=1.5, zorder=1)
                            # 添加方向箭头
                            plt.arrow(from_node.x, from_node.y, 
                                     (to_node.x - from_node.x) * 0.9, 
                                     (to_node.y - from_node.y) * 0.9,
                                     head_width=1, head_length=1, fc=route_color, 
                                     ec=route_color, zorder=2)
    
    # 添加节点类型图例
    node_legend = [
        Line2D([0], [0], marker='s', color='w', markerfacecolor='red', markersize=10, label='中转站'),
        Line2D([0], [0], marker='D', color='w', markerfacecolor='purple', markersize=10, label='需求点'),
        Line2D([0], [0], marker='*', color='w', markerfacecolor='yellow', markersize=15, label='开放中转站')
    ]
    
    legend_elements = node_legend + legend_elements
    plt.legend(handles=legend_elements, loc='upper right')
    plt.title('第二层级载重车路径规划', fontsize=15)
    plt.xlabel('X坐标')
    plt.ylabel('Y坐标')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.savefig('second_level_routes.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("第一层级路径图已保存为 'first_level_routes.png'")
    print("第二层级路径图已保存为 'second_level_routes.png'")

def plot_waste_distribution(problem, solution):
    """可视化废物分布和流向"""
    plt.figure(figsize=(12, 8))
    
    # 收集废物类型数据
    raw_waste_types = problem.waste_types
    processed_waste_types = problem.processed_waste_types
    
    # 计算原始废物总量
    raw_waste_amounts = {waste_type: 0 for waste_type in raw_waste_types}
    for node in problem.nodes:
        if node.type == 'generation' and hasattr(node, 'waste_generation'):
            for waste_type, amount in node.waste_generation.items():
                if waste_type in raw_waste_amounts:
                    raw_waste_amounts[waste_type] += amount
    
    # 计算处理后的废物分配
    processed_waste = {waste_type: 0 for waste_type in processed_waste_types}
    
    # 根据转化率计算处理后废物总量
    for raw_type, amount in raw_waste_amounts.items():
        if raw_type in problem.conversion_rates:
            for proc_type, rate in problem.conversion_rates[raw_type].items():
                processed_waste[proc_type] += amount * rate
    
    # 绘制桑基图
    # 由于桑基图比较复杂，这里只绘制简单的条形图
    
    # 创建两个子图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 8))
    
    # 原始废物条形图
    raw_types = list(raw_waste_amounts.keys())
    raw_values = list(raw_waste_amounts.values())
    ax1.bar(raw_types, raw_values, color='skyblue')
    ax1.set_title('原始废物类型分布')
    ax1.set_ylabel('废物量')
    ax1.grid(axis='y', linestyle='--', alpha=0.7)
    
    # 处理后废物条形图
    proc_types = list(processed_waste.keys())
    proc_values = list(processed_waste.values())
    ax2.bar(proc_types, proc_values, color='lightgreen')
    ax2.set_title('处理后废物类型分布')
    ax2.set_ylabel('废物量')
    ax2.grid(axis='y', linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    plt.savefig('waste_distribution.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 可视化未收集的废物量
    if solution.uncollected_waste:
        plt.figure(figsize=(10, 6))
        
        # 收集未收集的废物数据
        uncollected_by_type = {waste_type: 0 for waste_type in raw_waste_types}
        
        for node_id, waste_dict in solution.uncollected_waste.items():
            for waste_type, amount in waste_dict.items():
                if waste_type in uncollected_by_type:
                    uncollected_by_type[waste_type] += amount
        
        # 只保留有数据的废物类型
        types_to_plot = [t for t in raw_waste_types if uncollected_by_type[t] > 0]
        values_to_plot = [uncollected_by_type[t] for t in types_to_plot]
        
        if types_to_plot:  # 如果有未收集的废物
            plt.bar(types_to_plot, values_to_plot, color='salmon')
            plt.title('未收集废物分布')
            plt.ylabel('未收集量')
            plt.grid(axis='y', linestyle='--', alpha=0.7)
            plt.savefig('uncollected_waste.png', dpi=300, bbox_inches='tight')
            plt.close()
            print("未收集废物分布图已保存为 'uncollected_waste.png'")
    
    print("废物分布图已保存为 'waste_distribution.png'")

if __name__ == "__main__":
    main()