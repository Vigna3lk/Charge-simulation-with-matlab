# 模块3: 遗传算法实现 (ga.py)
import random
import numpy as np
from typing import List, Tuple
from problem import Problem
from solution import Solution, Route

class GeneticAlgorithm:
    def __init__(self, problem: Problem, pop_size=50, max_gen=100, 
                 crossover_rate=0.8, mutation_rate=0.2):
        self.problem = problem
        self.pop_size = pop_size
        self.max_gen = max_gen
        self.crossover_rate = crossover_rate
        self.mutation_rate = mutation_rate
        
    def initialize_population(self) -> List[Solution]:
        """初始化种群"""
        population = []
        for _ in range(self.pop_size):
            sol = self.generate_random_solution()
            sol.repair()  # 确保解是可行的
            population.append(sol)
        return population
    
    def generate_random_solution(self) -> Solution:
        """生成随机解"""
        sol = Solution(self.problem)
        
        # 1. 随机选择中转站开放状态
        transfer_nodes = [n.id for n in self.problem.nodes if n.type == 'transfer']
        for tid in transfer_nodes:
            sol.transfer_stations[tid] = random.random() > 0.5
        
        # 确保至少有一个中转站是开放的
        if all(not is_open for is_open in sol.transfer_stations.values()):
            if transfer_nodes:
                sol.transfer_stations[random.choice(transfer_nodes)] = True
        
        # 2. 随机分配产生点到中转站
        generation_nodes = [n for n in self.problem.nodes if n.type == 'generation']
        open_transfers = [tid for tid, is_open in sol.transfer_stations.items() if is_open]
        
        if open_transfers:  # 确保有开放的中转站
            for gen_node in generation_nodes:
                sol.generation_to_transfer[gen_node.id] = random.choice(open_transfers)
        
        # 3. 随机分配处理后废物到需求点
        demand_nodes = [n for n in self.problem.nodes if n.type == 'demand']
        for tid, is_open in sol.transfer_stations.items():
            if is_open:
                sol.transfer_to_demand[tid] = {}
                for waste_type in self.problem.processed_waste_types:
                    suitable_demands = [n.id for n in demand_nodes if n.demand_type == waste_type]
                    if suitable_demands:
                        sol.transfer_to_demand[tid][waste_type] = random.choice(suitable_demands)
        
        # 4. 构建第一层级路径
        self._build_first_level_routes(sol)
        
        # 5. 构建第二层级路径
        self._build_second_level_routes(sol)
        
        return sol
    
    def _build_first_level_routes(self, sol: Solution):
        """构建第一层级路径"""
        # 对每个开放的中转站
        for transfer_id, is_open in sol.transfer_stations.items():
            if is_open:
                # 找出分配给该中转站的产生点
                assigned_gens = [gen_id for gen_id, tid in sol.generation_to_transfer.items() if tid == transfer_id]
                
                if assigned_gens:
                    # 使用简单的贪婪策略构建路径
                    sol.first_level_routes[transfer_id] = []
                    current_route = Route([transfer_id])  # 从中转站开始
                    current_load = 0
                    current_energy = self.problem.battery_capacity
                    
                    # 为简化起见，我们使用最近邻算法构建路线
                    remaining_gens = assigned_gens.copy()
                    current_node = transfer_id
                    
                    while remaining_gens:
                        # 找出最近的产生点
                        next_gen = min(remaining_gens, 
                                      key=lambda g: self.problem.distance_matrix[current_node, g])
                        
                        # 计算到下一点的能耗
                        energy_needed = self.problem.distance_matrix[current_node, next_gen] * self.problem.energy_consumption
                        
                        # 检查是否需要充电
                        if energy_needed > current_energy:
                            # 需要充电，找最近的充电站
                            nearest_charging = self.problem.get_nearest_charging(current_node)
                            
                            if nearest_charging != -1:
                                # 添加充电站到路径
                                current_route.path.append(nearest_charging)
                                
                                # 更新能量
                                energy_to_charging = self.problem.distance_matrix[current_node, nearest_charging] * self.problem.energy_consumption
                                current_energy -= energy_to_charging
                                current_route.energy_usage.append(energy_to_charging)
                                current_route.remaining_energy.append(current_energy)
                                
                                # 充满电
                                current_energy = self.problem.battery_capacity
                                current_node = nearest_charging
                        
                        # 添加产生点到路径
                        current_route.path.append(next_gen)
                        
                        # 更新能量
                        energy_used = self.problem.distance_matrix[current_node, next_gen] * self.problem.energy_consumption
                        current_energy -= energy_used
                        current_route.energy_usage.append(energy_used)
                        current_route.remaining_energy.append(current_energy)
                        
                        # 更新当前位置
                        current_node = next_gen
                        
                        # 从剩余列表中移除
                        remaining_gens.remove(next_gen)
                        
                        # 更新装载量信息
                        gen_node = next(n for n in self.problem.nodes if n.id == next_gen)
                        if next_gen not in current_route.loads:
                            current_route.loads[next_gen] = {}
                            
                        for waste_type, amount in gen_node.waste_generation.items():
                            current_route.loads[next_gen][waste_type] = amount
                            current_load += amount
                        
                        # 如果车辆满载或没有更多产生点，结束当前路径
                        if current_load >= self.problem.vehicle_capacity or not remaining_gens:
                            # 回到中转站
                            energy_to_return = self.problem.distance_matrix[current_node, transfer_id] * self.problem.energy_consumption
                            
                            # 检查是否需要充电才能回到中转站
                            if energy_to_return > current_energy:
                                nearest_charging = self.problem.get_nearest_charging(current_node)
                                
                                if nearest_charging != -1:
                                    # 添加充电站到路径
                                    current_route.path.append(nearest_charging)
                                    
                                    # 更新能量
                                    energy_to_charging = self.problem.distance_matrix[current_node, nearest_charging] * self.problem.energy_consumption
                                    current_energy -= energy_to_charging
                                    current_route.energy_usage.append(energy_to_charging)
                                    current_route.remaining_energy.append(current_energy)
                                    
                                    # 充满电
                                    current_energy = self.problem.battery_capacity
                                    current_node = nearest_charging
                            
                            # 路径回到中转站
                            current_route.path.append(transfer_id)
                            energy_used = self.problem.distance_matrix[current_node, transfer_id] * self.problem.energy_consumption
                            current_route.energy_usage.append(energy_used)
                            current_route.remaining_energy.append(current_energy - energy_used)
                            
                            # 保存当前路径
                            sol.first_level_routes[transfer_id].append(current_route)
                            
                            # 如果还有未访问的产生点，创建新路径
                            if remaining_gens:
                                current_route = Route([transfer_id])  # 从中转站开始
                                current_load = 0
                                current_energy = self.problem.battery_capacity
                                current_node = transfer_id
    
    def _build_second_level_routes(self, sol: Solution):
        """构建第二层级路径"""
        # 对每个需求点
        demand_nodes = [n for n in self.problem.nodes if n.type == 'demand']
        
        for demand_node in demand_nodes:
            demand_id = demand_node.id
            waste_type = demand_node.demand_type
            
            # 找出需要将此类废物送到该需求点的中转站
            relevant_transfers = []
            for tid, waste_demand_map in sol.transfer_to_demand.items():
                if waste_type in waste_demand_map and waste_demand_map[waste_type] == demand_id:
                    relevant_transfers.append(tid)
            
            if relevant_transfers:
                # 为每个需求点创建路径集合
                sol.second_level_routes[demand_id] = []
                
                # 简单策略：每辆车访问多个中转站
                current_route = Route([demand_id])  # 从需求点开始
                current_load = 0
                
                # 使用简单的贪婪策略
                remaining_transfers = relevant_transfers.copy()
                current_node = demand_id
                
                while remaining_transfers:
                    # 找出最近的中转站
                    next_transfer = min(remaining_transfers, 
                                       key=lambda t: self.problem.distance_matrix[current_node, t])
                    
                    # 添加中转站到路径
                    current_route.path.append(next_transfer)
                    
                    # 更新当前位置
                    current_node = next_transfer
                    
                    # 从剩余列表中移除
                    remaining_transfers.remove(next_transfer)
                    
                    # 估算该中转站的废物量(基于分配给它的产生点)
                    transfer_waste = 0
                    for gen_id, tid in sol.generation_to_transfer.items():
                        if tid == next_transfer:
                            gen_node = next(n for n in self.problem.nodes if n.id == gen_id)
                            for w_type, amount in gen_node.waste_generation.items():
                                # 计算转化为当前需求点处理的废物量
                                transfer_waste += amount * self.problem.conversion_rates[w_type][waste_type]
                    
                    # 更新装载量信息
                    if next_transfer not in current_route.loads:
                        current_route.loads[next_transfer] = {}
                    current_route.loads[next_transfer][waste_type] = transfer_waste
                    current_load += transfer_waste
                    
                    # 如果车辆满载或没有更多中转站，结束当前路径
                    if current_load >= self.problem.vehicle_capacity or not remaining_transfers:
                        # 路径回到需求点
                        current_route.path.append(demand_id)
                        
                        # 保存当前路径
                        sol.second_level_routes[demand_id].append(current_route)
                        
                        # 如果还有未访问的中转站，创建新路径
                        if remaining_transfers:
                            current_route = Route([demand_id])  # 从需求点开始
                            current_load = 0
                            current_node = demand_id
    
    def selection(self, population: List[Solution], fitness: List[float]) -> List[Solution]:
        """选择操作 - 使用锦标赛选择"""
        selected = []
        while len(selected) < len(population):
            # 随机选择两个个体进行比较
            candidates = random.sample(list(enumerate(population)), 2)
            best_idx = max(candidates, key=lambda x: fitness[x[0]])[0]
            selected.append(population[best_idx])
        return selected
    
    def crossover(self, parent1: Solution, parent2: Solution) -> Tuple[Solution, Solution]:
        """交叉操作"""
        if random.random() > self.crossover_rate:
            return parent1, parent2
        
        child1 = parent1.copy()
        child2 = parent2.copy()
        
        # 1. 交换中转站开放状态
        transfer_ids = list(parent1.transfer_stations.keys())
        if transfer_ids:
            crossover_point = random.randint(1, len(transfer_ids) - 1)
            for i, tid in enumerate(transfer_ids):
                if i >= crossover_point:
                    child1.transfer_stations[tid] = parent2.transfer_stations[tid]
                    child2.transfer_stations[tid] = parent1.transfer_stations[tid]
        
        # 2. 交换产生点分配
        gen_ids = list(parent1.generation_to_transfer.keys())
        if gen_ids:
            crossover_point = random.randint(1, len(gen_ids) - 1)
            for i, gid in enumerate(gen_ids):
                if i >= crossover_point:
                    if gid in parent2.generation_to_transfer:
                        child1.generation_to_transfer[gid] = parent2.generation_to_transfer[gid]
                    if gid in parent1.generation_to_transfer:
                        child2.generation_to_transfer[gid] = parent1.generation_to_transfer[gid]
        
        # 重建路径
        self._build_first_level_routes(child1)
        self._build_first_level_routes(child2)
        self._build_second_level_routes(child1)
        self._build_second_level_routes(child2)
        
        return child1, child2
    
    def mutate(self, solution: Solution) -> Solution:
        """变异操作"""
        if random.random() > self.mutation_rate:
            return solution
        
        mutated = solution.copy()
        
        # 选择变异类型
        mutation_type = random.choice(['transfer', 'assignment', 'route'])
        
        if mutation_type == 'transfer':
            # 随机改变一个中转站的开放状态
            if mutated.transfer_stations:
                tid = random.choice(list(mutated.transfer_stations.keys()))
                mutated.transfer_stations[tid] = not mutated.transfer_stations[tid]
                
        elif mutation_type == 'assignment':
            # 随机重分配一个产生点
            if mutated.generation_to_transfer:
                gid = random.choice(list(mutated.generation_to_transfer.keys()))
                open_transfers = [tid for tid, is_open in mutated.transfer_stations.items() if is_open]
                if open_transfers:
                    mutated.generation_to_transfer[gid] = random.choice(open_transfers)
                
        elif mutation_type == 'route':
            # 随机选择一个路径并交换两个节点
            if mutated.first_level_routes:
                transfer_id = random.choice(list(mutated.first_level_routes.keys()))
                if mutated.first_level_routes[transfer_id]:
                    route_idx = random.randrange(len(mutated.first_level_routes[transfer_id]))
                    route = mutated.first_level_routes[transfer_id][route_idx]
                    if len(route.path) > 3:  # 确保有足够的节点进行交换
                        # 避免交换depot节点
                        idx1 = random.randint(1, len(route.path) - 2)
                        idx2 = random.randint(1, len(route.path) - 2)
                        route.path[idx1], route.path[idx2] = route.path[idx2], route.path[idx1]
        
        # 重建路径以确保一致性
        self._build_first_level_routes(mutated)
        self._build_second_level_routes(mutated)
        
        return mutated
    
    def replacement(self, population: List[Solution], offspring: List[Solution]) -> List[Solution]:
        """替换操作 - 精英保留策略"""
        # 计算所有个体的适应度
        all_solutions = population + offspring
        all_fitness = [1/sol.calculate_cost() if sol.is_feasible() else 0 for sol in all_solutions]
        
        # 按适应度降序排列
        sorted_indices = sorted(range(len(all_solutions)), key=lambda i: all_fitness[i], reverse=True)
        
        # 保留最好的pop_size个体
        new_population = [all_solutions[i] for i in sorted_indices[:self.pop_size]]
        return new_population
    
    def run(self) -> Solution:
        """运行遗传算法"""
        population = self.initialize_population()
        best_solution = None
        best_cost = float('inf')
        
        for gen in range(self.max_gen):
            # 评估适应度
            fitness = [1/sol.calculate_cost() if sol.is_feasible() else 0 for sol in population]
            
            # 找出当前最佳解
            best_idx = max(range(len(fitness)), key=lambda i: fitness[i])
            current_best = population[best_idx]
            current_cost = current_best.calculate_cost()
            
            if current_cost < best_cost and current_best.is_feasible():
                best_solution = current_best.copy()
                best_cost = current_cost
            
            # 选择操作
            selected = self.selection(population, fitness)
            
            # 交叉变异
            offspring = []
            for i in range(0, len(selected), 2):
                if i + 1 < len(selected):
                    parent1, parent2 = selected[i], selected[i+1]
                    child1, child2 = self.crossover(parent1, parent2)
                    offspring.extend([self.mutate(child1), self.mutate(child2)])
            
            # 新一代种群
            population = self.replacement(population, offspring)
            
            # 输出进度
            if gen % 10 == 0:
                print(f"Generation {gen}, Best cost: {best_cost}")
        
        return best_solution if best_solution else population[0]