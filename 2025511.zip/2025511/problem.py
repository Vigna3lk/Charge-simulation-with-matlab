# 模块1: 数据结构定义 (problem.py)
import numpy as np
from typing import List, Dict, Tuple

class Node:
    def __init__(self, node_id: int, node_type: str, x: float, y: float):
        self.id = node_id
        self.type = node_type  # 'generation', 'transfer', 'charging', 'demand'
        self.x = x
        self.y = y
        # 针对产生点，增加废物生成量
        self.waste_generation = {}  # {waste_type: volume}
        # 针对中转站，增加建设成本
        self.setup_cost = 0.0
        # 针对需求点，增加处理的废物类型
        self.demand_type = None

class Problem:
    def __init__(self):
        self.nodes: List[Node] = []
        self.distance_matrix: np.ndarray = None
        
        # 车辆相关参数
        self.vehicle_capacity = 1000  # 车辆容量示例
        self.battery_capacity = 500   # 电量容量示例
        self.energy_consumption = 1.0 # 单位距离能耗
        
        # 成本参数
        self.ev_fixed_cost = 100.0  # 第一层级电动车固定成本
        self.truck_fixed_cost = 150.0  # 第二层级载重车固定成本
        self.ev_transport_cost = 1.0  # 第一层级电动车运输成本(每公里)
        self.truck_transport_cost = 1.5  # 第二层级载重车运输成本(每公里)
        self.charging_cost = 0.5  # 充电成本(每单位电量)
        self.penalty_cost = 1000.0  # 未收集废物的惩罚成本(每单位)
        
        # 废物类型
        self.waste_types = ["concrete", "brick", "wood", "metal"]  # 初始废物类型
        self.processed_waste_types = ["recyclable", "non_recyclable", "reusable"]  # 处理后废物类型
        
        # 废物转化率矩阵: waste_type -> processed_type
        self.conversion_rates = {
            "concrete": {"recyclable": 0.7, "non_recyclable": 0.2, "reusable": 0.1},
            "brick": {"recyclable": 0.6, "non_recyclable": 0.3, "reusable": 0.1},
            "wood": {"recyclable": 0.5, "non_recyclable": 0.3, "reusable": 0.2},
            "metal": {"recyclable": 0.8, "non_recyclable": 0.1, "reusable": 0.1}
        }
    
    def calculate_distances(self):
        n = len(self.nodes)
        self.distance_matrix = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                if i != j:
                    dx = self.nodes[i].x - self.nodes[j].x
                    dy = self.nodes[i].y - self.nodes[j].y
                    self.distance_matrix[i,j] = np.sqrt(dx**2 + dy**2)
                
    def get_nearest_charging(self, current_node_id: int) -> int:
        charging_nodes = [n.id for n in self.nodes if n.type == 'charging']
        if not charging_nodes:
            return -1  # 无充电站
        distances = [self.distance_matrix[current_node_id, c] for c in charging_nodes]
        return charging_nodes[np.argmin(distances)]
    
    def generate_test_data(self, num_generation=30, num_transfer=10, 
                           num_charging=5, num_demand=3, area_size=100):
        """生成测试数据"""
        self.nodes = []
        node_id = 0
        
        # 生成产生点
        for i in range(num_generation):
            node = Node(node_id, 'generation', 
                      np.random.uniform(0, area_size), 
                      np.random.uniform(0, area_size))
            # 为每个产生点生成废物量
            for waste_type in self.waste_types:
                node.waste_generation[waste_type] = np.random.uniform(10, 50)
            self.nodes.append(node)
            node_id += 1
            
        # 生成中转站候选点
        for i in range(num_transfer):
            node = Node(node_id, 'transfer', 
                      np.random.uniform(0, area_size), 
                      np.random.uniform(0, area_size))
            node.setup_cost = np.random.uniform(500, 1500)
            self.nodes.append(node)
            node_id += 1
            
        # 生成充电站
        for i in range(num_charging):
            node = Node(node_id, 'charging', 
                      np.random.uniform(0, area_size), 
                      np.random.uniform(0, area_size))
            self.nodes.append(node)
            node_id += 1
            
        # 生成需求点(每个只处理一种处理后的废物)
        for i, waste_type in enumerate(self.processed_waste_types):
            if i < num_demand:
                node = Node(node_id, 'demand', 
                          np.random.uniform(0, area_size), 
                          np.random.uniform(0, area_size))
                node.demand_type = waste_type
                self.nodes.append(node)
                node_id += 1
                
        # 计算距离矩阵
        self.calculate_distances()
        
        return self