# 模块2: 解表示与评估 (solution.py)
from typing import List, Dict, Tuple
import copy
import numpy as np
from problem import Problem

class Route:
    def __init__(self, path: List[int] = None):
        self.path = path if path else []  # 节点ID序列
        self.loads = {}  # 各节点各类型废物装载量 {node_id: {waste_type: amount}}
        self.energy_usage = []  # 各段能量消耗
        self.remaining_energy = []  # 各节点剩余能量

class Solution:
    def __init__(self, problem: Problem):
        self.problem = problem
        self.transfer_stations: Dict[int, bool] = {}  # 中转站开放状态
        self.first_level_routes: Dict[int, List[Route]] = {}  # 第一层级路径 {transfer_id: [route1, route2...]}
        self.second_level_routes: Dict[int, List[Route]] = {}  # 第二层级路径 {demand_id: [route1, route2...]}
        
        # 废物分配
        self.generation_to_transfer = {}  # {gen_id: transfer_id}
        self.transfer_to_demand = {}  # {transfer_id: {waste_type: demand_id}}
        
        # 未收集废物量
        self.uncollected_waste = {}  # {node_id: {waste_type: amount}}
        
        # 初始化
        self._initialize_transfer_stations()
        
    def _initialize_transfer_stations(self):
        """初始化所有中转站为关闭状态"""
        for node in self.problem.nodes:
            if node.type == 'transfer':
                self.transfer_stations[node.id] = False
        
    def calculate_cost(self) -> float:
        """计算总成本"""
        total_cost = 0.0
        
        # 1. 中转站建设成本
        for node_id, is_open in self.transfer_stations.items():
            if is_open:
                node = next(n for n in self.problem.nodes if n.id == node_id)
                total_cost += node.setup_cost
        
        # 2. 车辆固定成本
        # 第一层级电动车固定成本
        for transfer_id, routes in self.first_level_routes.items():
            total_cost += len(routes) * self.problem.ev_fixed_cost
            
        # 第二层级载重车固定成本
        for demand_id, routes in self.second_level_routes.items():
            total_cost += len(routes) * self.problem.truck_fixed_cost
        
        # 3. 运输成本
        # 第一层级运输成本
        for transfer_id, routes in self.first_level_routes.items():
            for route in routes:
                for i in range(len(route.path) - 1):
                    from_node = route.path[i]
                    to_node = route.path[i + 1]
                    distance = self.problem.distance_matrix[from_node, to_node]
                    total_cost += distance * self.problem.ev_transport_cost
        
        # 第二层级运输成本
        for demand_id, routes in self.second_level_routes.items():
            for route in routes:
                for i in range(len(route.path) - 1):
                    from_node = route.path[i]
                    to_node = route.path[i + 1]
                    distance = self.problem.distance_matrix[from_node, to_node]
                    total_cost += distance * self.problem.truck_transport_cost
        
        # 4. 充电成本
        for transfer_id, routes in self.first_level_routes.items():
            for route in routes:
                for i in range(len(route.energy_usage)):
                    total_cost += route.energy_usage[i] * self.problem.charging_cost
        
        # 5. 未收集废物惩罚成本
        for node_id, waste_dict in self.uncollected_waste.items():
            for waste_type, amount in waste_dict.items():
                total_cost += amount * self.problem.penalty_cost
        
        return total_cost
    
    def is_feasible(self) -> bool:
        """检查所有约束条件"""
        return (self.check_capacity() and 
                self.check_energy() and 
                self.check_all_served() and
                self.check_route_continuity())
    
    def check_capacity(self) -> bool:
        """检查容量约束"""
        # 第一层级车辆容量检查
        for transfer_id, routes in self.first_level_routes.items():
            for route in routes:
                total_load = 0
                for node_id, loads in route.loads.items():
                    for waste_type, amount in loads.items():
                        total_load += amount
                if total_load > self.problem.vehicle_capacity:
                    return False
        
        # 第二层级车辆容量检查
        for demand_id, routes in self.second_level_routes.items():
            for route in routes:
                total_load = 0
                for node_id, loads in route.loads.items():
                    for waste_type, amount in loads.items():
                        total_load += amount
                if total_load > self.problem.vehicle_capacity:
                    return False
        
        return True
    
    def check_energy(self) -> bool:
        """检查能量约束"""
        for transfer_id, routes in self.first_level_routes.items():
            for route in routes:
                if not route.remaining_energy:
                    continue
                
                # 确保任何时候剩余能量都不为负
                if any(e < 0 for e in route.remaining_energy):
                    return False
        return True
    
    def check_all_served(self) -> bool:
        """检查所有节点是否被服务"""
        # 检查所有产生点是否被分配
        for node in self.problem.nodes:
            if node.type == 'generation':
                if node.id not in self.generation_to_transfer:
                    return False
        
        # 检查所有开放中转站是否被分配到需求点
        for transfer_id, is_open in self.transfer_stations.items():
            if is_open:
                if transfer_id not in self.transfer_to_demand:
                    return False
                
        return True
    
    def check_route_continuity(self) -> bool:
        """检查路径连续性"""
        # 第一层级路径连续性检查
        for transfer_id, routes in self.first_level_routes.items():
            for route in routes:
                if not route.path:
                    continue
                    
                # 路径必须从中转站开始
                if route.path[0] != transfer_id:
                    return False
                    
                # 路径必须回到中转站
                if route.path[-1] != transfer_id:
                    return False
        
        # 第二层级路径连续性检查
        for demand_id, routes in self.second_level_routes.items():
            for route in routes:
                if not route.path:
                    continue
                    
                # 路径必须从需求点开始
                if route.path[0] != demand_id:
                    return False
                    
                # 路径必须回到需求点
                if route.path[-1] != demand_id:
                    return False
        
        return True
    
    def copy(self):
        """创建解的深拷贝"""
        new_solution = Solution(self.problem)
        new_solution.transfer_stations = copy.deepcopy(self.transfer_stations)
        new_solution.first_level_routes = copy.deepcopy(self.first_level_routes)
        new_solution.second_level_routes = copy.deepcopy(self.second_level_routes)
        new_solution.generation_to_transfer = copy.deepcopy(self.generation_to_transfer)
        new_solution.transfer_to_demand = copy.deepcopy(self.transfer_to_demand)
        new_solution.uncollected_waste = copy.deepcopy(self.uncollected_waste)
        return new_solution

    def repair(self):
        """修复不可行解"""
        # 确保至少开放一个中转站
        if all(not is_open for is_open in self.transfer_stations.values()):
            transfer_ids = list(self.transfer_stations.keys())
            if transfer_ids:
                self.transfer_stations[np.random.choice(transfer_ids)] = True
        
        # 确保每个产生点都被分配
        for node in self.problem.nodes:
            if node.type == 'generation' and node.id not in self.generation_to_transfer:
                # 找出已开放的中转站
                open_transfers = [tid for tid, is_open in self.transfer_stations.items() if is_open]
                if open_transfers:
                    self.generation_to_transfer[node.id] = np.random.choice(open_transfers)
        
        # 确保每个开放的中转站都有废物分配到需求点
        demand_nodes = [n for n in self.problem.nodes if n.type == 'demand']
        for transfer_id, is_open in self.transfer_stations.items():
            if is_open and transfer_id not in self.transfer_to_demand:
                self.transfer_to_demand[transfer_id] = {}
                for waste_type in self.problem.processed_waste_types:
                    # 找出处理此类废物的需求点
                    suitable_demands = [n.id for n in demand_nodes if n.demand_type == waste_type]
                    if suitable_demands:
                        self.transfer_to_demand[transfer_id][waste_type] = np.random.choice(suitable_demands)